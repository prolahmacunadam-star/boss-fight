extends Button

@onready var tex = $TextureRect

var gorsel1 = preload("res://FIGHT_sprite_button.png")
var gorsel2 = preload("res://fight.png")

func _ready():
	tex.texture = gorsel1
	button_down.connect(_basildi)
	button_up.connect(_birakildi)

func _basildi():
	tex.texture = gorsel2

func _birakildi():
	tex.texture = gorsel1
