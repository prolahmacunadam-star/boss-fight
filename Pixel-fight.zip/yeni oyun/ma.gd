extends CheckButton

func _ready():
	button_pressed = AudioServer.is_bus_mute(0)

func _toggled(button_pressed):
	AudioServer.set_bus_mute(0, button_pressed)
