extends Control

func _on_button_pressed():
	$AnimationPlayer.play("fade")
	await $AnimationPlayer.animation_finished
	get_tree().change_scene_to_file("res://ayarlar.tscn")
